package main

import "github.com/junegunn/fzf/src"

func main() {
	fzf.Run(fzf.ParseOptions())
}
